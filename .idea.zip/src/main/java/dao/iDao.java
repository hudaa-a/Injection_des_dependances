package dao;

public interface iDao {
    double getData();
}

